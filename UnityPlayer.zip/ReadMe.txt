This is a simple marble shooting game created as an assignment by Prateek Chauhan (github - prateekrajsingh22).

Overview of gameplay - 

To run the game, just run "Marble Game.exe".

1. Put the aim crosshairs at a places desired for shooting.
2. Hold the blue (player) marble till the required force is gotten, see force bar at left, for reference.
3. To reset, just touch/click the Reset (blue) button place at bottom right corner.
4. To change colours of trail of the player, press the rainbow coloured button, placed at middle-right side.
	There are 4 trail colours - Blue (default), Red, Yellow, Green.
5. To quit, just use the top-right cornered Cross button.

Enjoy. Thank You.